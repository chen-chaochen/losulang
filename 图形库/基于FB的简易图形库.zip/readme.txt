基于freebasic的简易图形库
缺陷
至少在windows平台下
启动后程序不再支持输出中文字符，GUI界面中文字符出现乱码


编译方法
fbc -dll -gen -gcc -Wc -o losuvm_gui.lsd losuvm_gui.bas
losuc 图形

复制 losuvm_gui.lsd 到 LS_ROOT/lvm
复制 图形.lsc 到 LS_ROOT/inc/洛书/