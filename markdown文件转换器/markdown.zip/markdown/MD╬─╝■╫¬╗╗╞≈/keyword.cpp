// HTML ǰ�ñ�ǩ
const std::string frontTag[] = { "", "<p>", "", "<ul>", "<ol>", "<li>", "<em>", "<strong>", "<hr color=#CCCCCC size=1 / > ", "", "<blockquote>", "<h1>", "<h2>", "<h3>", "<h4>", "<h5>", "<h6>", "<pre><code>", "<code>" };
// HTML ���ñ�ǩ
const std::string backTag[] = {"", "</p>", "", "</ul>", "</ol>", "</li>", "</em>",	"</strong>", "", "", "</blockquote>", "</h1>", "</h2>",	"</h3>", "</h4>", "</h5>", "</h6>", "</code></pre>", "</code>" };
