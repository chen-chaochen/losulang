#include <iostream>
#include<string>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
int main (){
    
    cout << "Content-type:text/html\r\n\r\n";
    cout << "<html>\n";
    cout << "<head>\n";
    cout << "<title>���齨վ</title>\n";
    cout << "</head>\n";
    cout << "<body>\n";
    cout << "<h2>"<<"hello"<<"</h2>\n";
    cout << "</body>\n";
    cout << "</html>\n";   
    exit(0);
    return 0;    
}
