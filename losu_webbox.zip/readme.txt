一个简易的web服务器
适合洛书程序进行调用
遵循GPL-3.0与洛书使用协议
2022/7/27

用法
当洛书程序启动服务式，解释器工作目录便会被设置为网站根目录
位于./cgi-bin目录下的文件会被作为cgi程序执行

编译	losuvm_httpd.cpp	 为 losuvm_httpd.lsd
编译	服务器.losu
复制文件到  ./lvm/洛书	 ./inc	 目录