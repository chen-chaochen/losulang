对洛书的分发需注明以下信息
/*
洛书汉语编程
Losu Program-language Kits 0.1.2
losu0.1.2
https://gitee.com/chen-chaochen/lpk
GPL-3.0
Chen-chaochen
2022/7/25
*/