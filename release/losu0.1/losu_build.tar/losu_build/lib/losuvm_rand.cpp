/*
LPK0.1
Losu Program-language Kits 0.1
Powered by chen-chaochen
https://gitee.com/chen-chaochen/lpk
License GPL-3.0 
*/

#include <iostream>
#include <cstdlib>
#include <ctime>
#define random(a,b) (rand()%(b + 1 -a)+a) 

using namespace std;
extern "C"{
const char* ls_rand(const char* _begin,const char* _end)
{
    srand((int)time(NULL));  
    return to_string(random(atoi(_begin),atoi(_end))).c_str();
}
}
